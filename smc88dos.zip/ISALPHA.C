/*
** return 'true' if c is alphabetic
*/
isalpha(c) int c; {
  return ((c<='z' && c>='a') || (c<='Z' && c>='A'));
  }
