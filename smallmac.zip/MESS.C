
/*
** mess.c -- message functions
*/
#include <stdio.h>
#define NOCCARGC
puts2(str1, str2) char *str1, *str2; {
  fputs(str1, stdout);
  puts(str2);
  }
cant(str) char *str; {
  error2(str, " - Can't Open");
  }
error2(str1, str2) char *str1, *str2; {
  fputs(str1, stdout);
  error(str2);
  }
error(str) char *str; {
  puts(str);
  abort(7);
  }
