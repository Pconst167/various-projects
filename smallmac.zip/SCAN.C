/*
** scanning functions
*/
#include <stdio.h>
#include "mac.h"
#define NOCCARGC

atend(ch) int ch; {			/* is ch at end of line? */
  switch(ch) {
    case COMMENT: case NULL: case '\n': return (YES);
    }
  return (NO);
  }

fldcmp(s, t) char *s, *t; {		/* compare fields in a line */
  while(lexorder(*s, *t) == 0) {
    if(!isgraph(*s)) return (0);
    ++s; ++t;
    }
  if((isspace(*s) || atend(*s)) &&
     (isspace(*t) || atend(*t))) return (0);
  return (*s - *t);
  }

skip(n, str) int n; char str[]; {	/* find nth non-blank field in str */
  char *cp; cp = str;
  while(isspace(*cp)) ++cp;
  while(--n) {
    while(isgraph(*cp)) ++cp;
    while(isspace(*cp)) ++cp;
    }
  return (cp);
  }
